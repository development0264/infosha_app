class VoteStatusModel {
  int status;
  int likeCount, disLikeCount;

  VoteStatusModel({
    required this.status,
    required this.likeCount,
    required this.disLikeCount,
  });
}
