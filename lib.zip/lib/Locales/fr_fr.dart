const Map<String, String> frFr = {
  'hello': 'Hello!',
  
};
