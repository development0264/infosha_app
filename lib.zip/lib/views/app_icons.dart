class APPICONS {
  static String infoWhitelogosvg = "images/infowhite.svg";
  static String settingsvg = "images/setting.svg";
  static String searchsvg = "images/search.svg";
  static String visitIcon = "images/visiticon.png";
  static String profilesvg = "images/profile.svg";
  static String followprofilesvg = "images/followprofile.svg";
  static String likesvg = "images/likesvg.svg";
  static String dislikesvg = "images/dislikesvg.svg";
  static String dislikedsvg = "images/disliked.svg";
  static String likedsvg = "images/liked.svg";

  static String lordicon = "images/vector.png";
  static String copyicon = "images/file.png";
  static String profileicon = "images/aysha.png";
  static String casespng = "images/cases.png";
  static String reactionpng = "images/reaction.png";
  static String lovepng = "assets/emojies/heart.png";
  static String wowpng = "assets/emojies/wow.png";

  static String carepng = "assets/emojies/care.png";
  static String sadpng = "assets/emojies/sad.png";
  static String angrypng = "assets/emojies/angry.png";
  static String lolpng = "assets/emojies/lol.png";
  static String kingstutspicpng = "images/kingstutspic.png";
  static String godstatuspng = "images/godstutspic.png";
  static String lordstutspng = "images/vector.png";

  static String socialMedia = "images/socialMedia.png";
  static String feedBackground = "images/feedBackground.png";
  static String feedImage = "images/feedImage.png";
  static String shareIcon = "images/shareIcon.png";
  static String replyIcon = "images/replySVG.svg";
  static String uploadIcon = "images/uploadIcon.png";
  static String searchResultIcon = "images/searchResultIcon.png";
}
